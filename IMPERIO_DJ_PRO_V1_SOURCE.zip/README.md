# IMPERIO DJ PRO V1.0 – Android source

Proyecto inicial Android nativo (Kotlin) con:
- Dos decks independientes basados en MediaPlayer.
- Carga de audio mediante selector de documentos.
- Controles básicos Play/Pause y volumen.
- Crossfader de volumen.
- Selección de dispositivo de salida para preescucha.
- Reproductor de preescucha separado para cada deck.

## Importante sobre la preescucha
La preescucha requiere una salida física separada (por ejemplo auriculares USB o cableados) y que Android permita enrutar el reproductor a ese dispositivo. Bluetooth puede tener latencia y algunos fabricantes limitan el enrutamiento simultáneo. El audio de los decks todavía usa el enrutamiento principal del sistema; esta primera base es un prototipo funcional inicial, no un mezclador profesional de baja latencia.

## Compilar
Abrir el proyecto en Android Studio con JDK 17 y Gradle 8.9 o compatible. Sincronizar y ejecutar la tarea `assembleDebug`.

## Próximas tareas
1. Persistir URIs de pistas y corregir ciclo de vida de preescucha.
2. Implementar servicio de audio en primer plano.
3. Sustituir MediaPlayer por motor PCM/Oboe para mezcla de baja latencia y buses de salida independientes.
4. Añadir BPM, waveform, EQ, Automix, loops, efectos y grabación.
