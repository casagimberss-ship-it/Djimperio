package com.imperio.djpro

import android.app.Activity
import android.content.Context
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private lateinit var engine: DjAudioEngine
    private lateinit var status: TextView
    private lateinit var deviceInfo: TextView
    private lateinit var crossfader: SeekBar
    private lateinit var cueDeck: Spinner
    private lateinit var outputSpinner: Spinner
    private val pickA = registerForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let { uri -> load(0, uri) } }
    private val pickB = registerForActivityResult(ActivityResultContracts.OpenDocument()) { it?.let { uri -> load(1, uri) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        engine = DjAudioEngine(this)
        buildUi()
        refreshOutputs()
    }

    private fun buildUi() {
        val bg = 0xFF101318.toInt()
        val panel = 0xFF1B222B.toInt()
        val accent = 0xFF24B7D8.toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(18, 12, 18, 12)
            setBackgroundColor(bg)
        }
        val title = TextView(this).apply {
            text = "IMPERIO DJ PRO"; textSize = 23f; setTextColor(-1); gravity = Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(-1, 48))
        val decks = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        decks.addView(deckPanel(0, panel, accent), LinearLayout.LayoutParams(0, 0, 1f).apply { height = 220 })
        decks.addView(deckPanel(1, panel, accent), LinearLayout.LayoutParams(0, 0, 1f).apply { height = 220 })
        root.addView(decks)
        val mixTitle = TextView(this).apply { text = "CROSSFADER MASTER"; setTextColor(-1); gravity = Gravity.CENTER; textSize = 14f }
        root.addView(mixTitle)
        crossfader = SeekBar(this).apply {
            max = 100; progress = 50
            setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) { engine.setCrossfader(p / 100f) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        root.addView(crossfader)
        val cueRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        cueRow.addView(TextView(this).apply { text="PREESCUCHA: "; setTextColor(-1) })
        cueDeck = Spinner(this)
        cueDeck.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf("Deck A","Deck B"))
        cueRow.addView(cueDeck, LinearLayout.LayoutParams(120, -1))
        val cue = Button(this).apply { text="CUE EN AURICULARES"; setOnClickListener { engine.preview(cueDeck.selectedItemPosition); updateStatus("Preescucha activada en auriculares (si están disponibles).") } }
        cueRow.addView(cue)
        root.addView(cueRow)
        val outRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        outRow.addView(TextView(this).apply { text="SALIDA DE AURICULARES: "; setTextColor(-1) })
        outputSpinner = Spinner(this)
        outRow.addView(outputSpinner, LinearLayout.LayoutParams(0, 52, 1f))
        val refresh = Button(this).apply { text="↻"; setOnClickListener { refreshOutputs() } }
        outRow.addView(refresh)
        root.addView(outRow)
        deviceInfo = TextView(this).apply { setTextColor(0xFFB6C1CC.toInt()); textSize=12f }
        root.addView(deviceInfo)
        status = TextView(this).apply { setTextColor(accent); text="Cargá una pista en cada deck para comenzar."; gravity=Gravity.CENTER; textSize=13f }
        root.addView(status, LinearLayout.LayoutParams(-1, 42))
        setContentView(root)
    }

    private fun deckPanel(index: Int, panel: Int, accent: Int): View {
        val box = LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; setPadding(12,8,12,8); setBackgroundColor(panel)
        }
        val name = TextView(this).apply { text=if(index==0) "DECK A" else "DECK B"; textSize=20f; setTextColor(accent); gravity=Gravity.CENTER }
        val track = TextView(this).apply { text="Sin pista cargada"; setTextColor(-1); gravity=Gravity.CENTER; textSize=12f }
        engine.setTrackLabel(index) { track.text=it }
        box.addView(name); box.addView(track, LinearLayout.LayoutParams(-1, 42))
        val load = Button(this).apply { text="CARGAR"; setOnClickListener { if(index==0) pickA.launch(arrayOf("audio/*")) else pickB.launch(arrayOf("audio/*")) } }
        box.addView(load)
        val controls = LinearLayout(this).apply { gravity=Gravity.CENTER }
        controls.addView(Button(this).apply { text="▶"; setOnClickListener { engine.play(index); updateStatus("Deck ${if(index==0) "A" else "B"} reproduciendo.") } })
        controls.addView(Button(this).apply { text="Ⅱ"; setOnClickListener { engine.pause(index) } })
        controls.addView(Button(this).apply { text="CUE"; setOnClickListener { engine.preview(index); cueDeck.setSelection(index); updateStatus("Preescuchando Deck ${if(index==0) "A" else "B"}.") } })
        box.addView(controls)
        val vol = SeekBar(this).apply { max=100; progress=100; setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s:SeekBar?,p:Int,user:Boolean){ engine.setDeckVolume(index,p/100f) }
            override fun onStartTrackingTouch(s:SeekBar?){}
            override fun onStopTrackingTouch(s:SeekBar?){}
        }) }
        box.addView(TextView(this).apply { text="VOLUMEN"; setTextColor(-1); textSize=10f })
        box.addView(vol)
        return box
    }

    private fun load(deck: Int, uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {}
        engine.load(deck, uri)
        updateStatus("Pista cargada en Deck ${if(deck==0) "A" else "B"}.")
    }

    private fun refreshOutputs() {
        val devices = engine.outputDevices()
        val labels = devices.map { "${it.productName} (${deviceType(it.type)})" }
        outputSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        val headphoneIndex = devices.indexOfFirst { it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES || it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET || it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || it.type == AudioDeviceInfo.TYPE_USB_HEADSET }
        if (headphoneIndex >= 0) outputSpinner.setSelection(headphoneIndex)
        outputSpinner.onItemSelectedListener = object: android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (devices.isNotEmpty()) {
                    engine.setCueOutput(devices[position])
                    deviceInfo.text = "Preescucha dirigida a: ${devices[position].productName}. La disponibilidad depende del dispositivo Android."
                }
            }
        }
        if (devices.isEmpty()) deviceInfo.text = "No se detectaron salidas de audio externas."
    }

    private fun deviceType(type:Int) = when(type) {
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_WIRED_HEADSET -> "Auriculares"
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> "Bluetooth"
        AudioDeviceInfo.TYPE_USB_HEADSET -> "USB"
        else -> "Salida"
    }
    private fun updateStatus(message:String) { status.text=message }
    override fun onDestroy() { engine.release(); super.onDestroy() }
}

private class DjAudioEngine(private val context: Context) {
    private val manager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val players = arrayOfNulls<MediaPlayer>(2)
    private val previews = arrayOfNulls<MediaPlayer>(2)
    private val labels = arrayOf<(String)->Unit>(2) { {} }
    private val volumes = floatArrayOf(1f,1f)
    private var cross = 0.5f
    private var cueDevice: AudioDeviceInfo? = null

    fun setTrackLabel(deck:Int, callback:(String)->Unit) { labels[deck]=callback }
    fun load(deck:Int, uri:Uri) {
        stopPreview(deck)
        players[deck]?.release()
        val player = MediaPlayer()
        player.setDataSource(context, uri)
        player.setOnPreparedListener { applyMix(); labels[deck]("Loaded: ${uri.lastPathSegment ?: "Audio track"}") }
        player.setOnErrorListener { _, what, extra -> labels[deck]("Error de reproducción ($what/$extra)"); true }
        players[deck]=player
        loadedUris[deck]=uri
        player.prepareAsync()
    }
    fun play(deck:Int) { players[deck]?.let { if(it.isPlaying) return else it.start(); applyMix() } }
    fun pause(deck:Int) { players[deck]?.pause() }
    fun setDeckVolume(deck:Int, value:Float) { volumes[deck]=value; applyMix() }
    fun setCrossfader(value:Float) { cross=value.coerceIn(0f,1f); applyMix() }
    private fun applyMix() {
        val a = (1f-cross) * volumes[0]
        val b = cross * volumes[1]
        players[0]?.setVolume(a,a)
        players[1]?.setVolume(b,b)
    }
    fun outputDevices():List<AudioDeviceInfo> = manager.getDevices(AudioManager.GET_DEVICES_OUTPUTS).filter {
        it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES || it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
        it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || it.type == AudioDeviceInfo.TYPE_USB_HEADSET ||
        it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER
    }
    fun setCueOutput(device:AudioDeviceInfo) { cueDevice=device; previews.forEach { it?.setPreferredDevice(device) } }
    fun preview(deck:Int) {
        val source = players[deck] ?: return
        val position = try { source.currentPosition } catch (_:Exception) { 0 }
        // Preview player uses an independent decoder and output route.
        val trackUri = loadedUris[deck] ?: return
        stopPreview(deck)
        val p=MediaPlayer()
        p.setDataSource(context, trackUri)
        cueDevice?.let { p.setPreferredDevice(it) }
        p.setOnPreparedListener { p.seekTo(position); p.start() }
        p.setOnCompletionListener { stopPreview(deck) }
        previews[deck]=p
        p.prepareAsync()
    }
    private val loadedUris = arrayOfNulls<Uri>(2)
    fun release() { players.forEach { it?.release() }; previews.forEach { it?.release() } }
    private fun stopPreview(deck:Int) { previews[deck]?.runCatching { stop(); release() }; previews[deck]=null }
}
